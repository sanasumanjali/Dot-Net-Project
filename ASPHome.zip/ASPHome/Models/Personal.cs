﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace ASPHome.Models
{
    public class Personal
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AppId { get; set; }
        [Required(ErrorMessage = "Required")]
        public int Id { get; set; }
        [Required(ErrorMessage = "Required")]

        public string FirstName { get; set; }
        [Required(ErrorMessage = "Required")]
        public string MiddleName { get; set; }
        [Required(ErrorMessage = "Required")]
      
        public string LastName { get; set; }
        [Required(ErrorMessage = "Required")]
        public string EmailId { get; set; }
        [Required(ErrorMessage = "Required")]
        public int Phonenumber { get; set; }
        [Required(ErrorMessage = "Required")]
        public double Salary { get; set; }
        [Required(ErrorMessage = "Required")]
        public string Gender { get; set; }
        [Required(ErrorMessage = "Required")]
        public string Nationality { get; set; }
        [Required(ErrorMessage = "Required")]

        public double Aadharnumber { get; set; }
        [Required(ErrorMessage = "Required")]

        public double Panno { get; set; }


    }
}