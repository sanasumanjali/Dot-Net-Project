﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace ASPHome.Models
{
   
    public class IncomeDetails
    {
       [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ApplicationId { get; set; }
        [Required(ErrorMessage ="Required")]
        [Display(Name = "ProperityLocation")]
        public string ProperityLocation { get; set; }

        [Required(ErrorMessage = "Required")]
        public string ProperityName { get; set; }
        [Required(ErrorMessage = "Required")]
        public double ESAmount { get; set; }
        [Required(ErrorMessage = "Required")]
        public string TypeofEmployeement { get; set; }
        [Required(ErrorMessage = "Required")]
        public int Retirementage { get; set; }
        [Required(ErrorMessage = "Required")]
        public string Organizationtype { get; set; }
        [Required(ErrorMessage = "Required")]
        public string EmployerName { get; set; }
       

    }
}