﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace ASPHome.Models
{
    public class Document
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required(ErrorMessage = "Required")]
        public byte[] PanCard { get; set; }
        [Required(ErrorMessage = "Required")]
        public byte[] VoterId { get; set; }
        [Required(ErrorMessage = "Required")]
        public byte[] SalarySlip { get; set; }
        [Required(ErrorMessage = "Required")]
        public byte[] LOA { get; set; }
        [Required(ErrorMessage = "Required")]
        public byte[] NOCFromBuilder { get; set; }
        [Required(ErrorMessage = "Required")]
        public byte[] AgreementToSale { get; set; }
    }
}