﻿namespace ASPHome.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Create : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Calculations",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        CustomerName = c.String(nullable: false),
                        Salary = c.Double(nullable: false),
                        ROI = c.Double(nullable: false),
                        LoanAmount = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.Documents",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        PanCard = c.Binary(nullable: false),
                        VoterId = c.Binary(nullable: false),
                        SalarySlip = c.Binary(nullable: false),
                        LOA = c.Binary(nullable: false),
                        NOCFromBuilder = c.Binary(nullable: false),
                        AgreementToSale = c.Binary(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.EMICalculations",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        CustomerName = c.String(nullable: false),
                        Salary = c.Double(nullable: false),
                        ROI = c.Double(nullable: false),
                        loantenure = c.Double(nullable: false),
                        EMI = c.Double(nullable: false),
                        LoanAmount = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.IncomeDetails",
                c => new
                    {
                        ApplicationId = c.Int(nullable: false, identity: true),
                        ProperityLocation = c.String(nullable: false),
                        ProperityName = c.String(nullable: false),
                        ESAmount = c.Double(nullable: false),
                        TypeofEmployeement = c.String(nullable: false),
                        Retirementage = c.Int(nullable: false),
                        Organizationtype = c.String(nullable: false),
                        EmployerName = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.ApplicationId);
            
            CreateTable(
                "dbo.Loans",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        EMI = c.Int(nullable: false),
                        ROI = c.Single(nullable: false),
                        Tenure = c.Int(nullable: false),
                        LoanAmount = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Personals",
                c => new
                    {
                        AppId = c.Int(nullable: false, identity: true),
                        Id = c.Int(nullable: false),
                        FirstName = c.String(nullable: false),
                        MiddleName = c.String(nullable: false),
                        LastName = c.String(nullable: false),
                        EmailId = c.String(nullable: false),
                        Phonenumber = c.Int(nullable: false),
                        Salary = c.Double(nullable: false),
                        Gender = c.String(nullable: false),
                        Nationality = c.String(nullable: false),
                        Aadharnumber = c.Double(nullable: false),
                        Panno = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.AppId);
            
            CreateTable(
                "dbo.SignIns",
                c => new
                    {
                        Id = c.Int(nullable: false),
                        User_Name = c.String(nullable: false),
                        User_EmailId = c.String(nullable: false),
                        Password = c.String(nullable: false),
                        Conformword = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.SignIns");
            DropTable("dbo.Personals");
            DropTable("dbo.Loans");
            DropTable("dbo.IncomeDetails");
            DropTable("dbo.EMICalculations");
            DropTable("dbo.Documents");
            DropTable("dbo.Calculations");
        }
    }
}
